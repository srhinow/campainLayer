Author: Sven Rhinow
Web: www.sr-tag.de
License: LPGL
Version: 0.5

deutsch
--------------------------------------
dieses Contao-Modul stellt die Möglichkeit zur Verfügung ein Layer in verschiedenen Arten anzuzeigen

- durch Klick auf eine Schaltfläche oder Link
- Aufruf beim betreten der Seite
- Übergabe von bestimmten GET-Parametern
- Die Anzeige kann durch COOKIES,SESSION und mit Start und Stop-Zeit limitiert werden
- die Anzeige kann zeitlich verzögert werden bevor der Layer erscheint
- Der Inhalt des Layers kann absolute flexible gestaltet werden da es den im Modul eingetragenen Text anzeigt und auch mit inserttags auf Artikel, Inhaltselemente und Module gesteuert werden kann

Vorraussetzung: dieses Modul basiert auf das Mootools-Framework
